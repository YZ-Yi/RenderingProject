1.use command line to select model(1.teapot 2.bunny 3.engine)
2.camera: wasd, lshift, space, mouse
2.light: ijkluo 